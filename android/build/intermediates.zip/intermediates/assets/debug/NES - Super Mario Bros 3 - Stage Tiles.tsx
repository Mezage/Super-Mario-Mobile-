<?xml version="1.0" encoding="UTF-8"?>
<tileset name="NES - Super Mario Bros 3 - Stage Tiles" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="1311" columns="69">
 <image source="EECS40_Giselle_Assignment4/android/assets/NES - Super Mario Bros 3 - Stage Tiles.png" trans="4242ff" width="1242" height="358"/>
</tileset>
