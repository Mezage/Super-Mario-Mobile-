<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SNES - Super Mario World - Cloud Tiles" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="216" columns="18">
 <image source="EECS40_Giselle_Assignment4/android/assets/SNES - Super Mario World - Cloud Tiles.png" width="325" height="231"/>
</tileset>
