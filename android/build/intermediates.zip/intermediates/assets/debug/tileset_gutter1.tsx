<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset_gutter" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="924" columns="33">
 <image source="EECS40_Giselle_Assignment4/android/assets/tileset_gutter.png" trans="63adff" width="594" height="504"/>
</tileset>
