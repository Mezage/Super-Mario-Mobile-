<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tilesetgutter" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="924" columns="33">
 <image source="tileset_gutter.png" width="594" height="504"/>
</tileset>
